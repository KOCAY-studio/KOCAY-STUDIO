
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Menu, X, Star, Play, Download, ShoppingCart, Eye, Heart, Share2, ArrowRight, CheckCircle, Smartphone, Palette, Code, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('semua');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const { toast } = useToast();

  const portfolioItems = [
    {
      id: 1,
      title: 'Portfolio Bisnis Modern',
      category: 'portfolio',
      price: 'Rp 299.000',
      originalPrice: 'Rp 499.000',
      rating: 4.9,
      reviews: 127,
      image: 'Modern business portfolio with sleek design',
      description: 'Template portfolio bisnis yang elegan dan profesional dengan desain modern',
      features: ['Responsive Design', 'SEO Optimized', 'Fast Loading', 'Mobile First'],
      demo: true
    },
    {
      id: 2,
      title: 'Landing Page E-Commerce',
      category: 'landing',
      price: 'Rp 399.000',
      originalPrice: 'Rp 699.000',
      rating: 4.8,
      reviews: 89,
      image: 'E-commerce landing page with product showcase',
      description: 'Landing page e-commerce yang converting tinggi dengan UI/UX terbaik',
      features: ['High Conversion', 'Payment Integration', 'Analytics Ready', 'A/B Test Ready'],
      demo: true
    },
    {
      id: 3,
      title: 'Portfolio Kreatif',
      category: 'portfolio',
      price: 'Rp 249.000',
      originalPrice: 'Rp 449.000',
      rating: 4.9,
      reviews: 156,
      image: 'Creative portfolio with artistic layout',
      description: 'Portfolio kreatif untuk designer dan artist dengan animasi menawan',
      features: ['Creative Animations', 'Gallery System', 'Contact Forms', 'Social Integration'],
      demo: true
    },
    {
      id: 4,
      title: 'Landing Page SaaS',
      category: 'landing',
      price: 'Rp 449.000',
      originalPrice: 'Rp 799.000',
      rating: 4.7,
      reviews: 203,
      image: 'SaaS landing page with modern interface',
      description: 'Landing page SaaS dengan konversi tinggi dan fitur lengkap',
      features: ['Subscription Ready', 'Dashboard Preview', 'Pricing Tables', 'Feature Showcase'],
      demo: true
    }
  ];

  const services = [
    {
      icon: Smartphone,
      title: 'Mobile-First Design',
      description: 'Desain yang dioptimalkan untuk pengalaman mobile terbaik'
    },
    {
      icon: Palette,
      title: 'UI/UX Premium',
      description: 'Interface yang indah dan user experience yang luar biasa'
    },
    {
      icon: Code,
      title: 'Clean Code',
      description: 'Kode yang bersih, terstruktur, dan mudah dikustomisasi'
    },
    {
      icon: Zap,
      title: 'Performance Tinggi',
      description: 'Loading cepat dan performa optimal di semua device'
    }
  ];

  const filteredProducts = selectedCategory === 'semua' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === selectedCategory);

  const handlePurchase = (product) => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      description: `Pembelian ${product.title}`,
    });
  };

  const handleDemo = (product) => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      description: `Demo ${product.title}`,
    });
  };

  const handleContact = () => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      description: "Kontak KOCAY Studio",
    });
  };

  return (
    <>
      <Helmet>
        <title>KOCAY Studio - Portfolio & Landing Page Digital Premium</title>
        <meta name="description" content="Jual dan promosi produk digital premium seperti portfolio dan landing page untuk bisnis Anda. Desain responsif dan modern dari KOCAY Studio." />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900">
        <Toaster />
        
        {/* Header */}
        <header className="fixed top-0 w-full z-50 bg-black/20 backdrop-blur-lg border-b border-white/10">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center space-x-3"
              >
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-lg">K</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">KOCAY Studio</h1>
                  <p className="text-xs text-purple-300">Digital Products</p>
                </div>
              </motion.div>

              {/* Desktop Navigation */}
              <nav className="hidden md:flex items-center space-x-8">
                <a href="#home" className="text-white hover:text-purple-300 transition-colors">Beranda</a>
                <a href="#products" className="text-white hover:text-purple-300 transition-colors">Produk</a>
                <a href="#services" className="text-white hover:text-purple-300 transition-colors">Layanan</a>
                <a href="#contact" className="text-white hover:text-purple-300 transition-colors">Kontak</a>
              </nav>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden text-white p-2"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="md:hidden bg-black/30 backdrop-blur-lg border-t border-white/10"
              >
                <nav className="container mx-auto px-4 py-4 space-y-4">
                  <a href="#home" className="block text-white hover:text-purple-300 transition-colors">Beranda</a>
                  <a href="#products" className="block text-white hover:text-purple-300 transition-colors">Produk</a>
                  <a href="#services" className="block text-white hover:text-purple-300 transition-colors">Layanan</a>
                  <a href="#contact" className="block text-white hover:text-purple-300 transition-colors">Kontak</a>
                </nav>
              </motion.div>
            )}
          </AnimatePresence>
        </header>

        {/* Hero Section */}
        <section id="home" className="pt-24 pb-16 px-4">
          <div className="container mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto"
            >
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
                Produk Digital
                <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"> Premium</span>
                <br />untuk Bisnis Anda
              </h1>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                Portfolio dan landing page berkualitas tinggi dengan desain responsif dan performa optimal untuk mengembangkan bisnis digital Anda
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-xl"
                  onClick={() => document.getElementById('products').scrollIntoView({ behavior: 'smooth' })}
                >
                  Lihat Produk <ArrowRight className="ml-2" size={20} />
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white px-8 py-3 rounded-xl"
                  onClick={handleContact}
                >
                  Konsultasi Gratis
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mt-16"
            >
              <img  
                className="w-full max-w-4xl mx-auto rounded-2xl shadow-2xl border border-white/10"
                alt="KOCAY Studio showcase"
               src="https://images.unsplash.com/photo-1688760871131-29afc15029ec" />
            </motion.div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-16 px-4">
          <div className="container mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Mengapa Pilih KOCAY Studio?
              </h2>
              <p className="text-gray-300 max-w-2xl mx-auto">
                Kami menghadirkan solusi digital terbaik dengan standar kualitas internasional
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {services.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10 hover:border-purple-400/50 transition-all duration-300"
                >
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-4">
                    <service.icon className="text-white" size={24} />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
                  <p className="text-gray-300">{service.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Products Section */}
        <section id="products" className="py-16 px-4">
          <div className="container mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Produk Digital Premium
              </h2>
              <p className="text-gray-300 max-w-2xl mx-auto mb-8">
                Koleksi template dan desain berkualitas tinggi untuk kebutuhan bisnis digital Anda
              </p>

              {/* Category Filter */}
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                {['semua', 'portfolio', 'landing'].map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-6 py-2 rounded-full transition-all duration-300 ${
                      selectedCategory === category
                        ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                        : 'bg-white/10 text-gray-300 hover:bg-white/20'
                    }`}
                  >
                    {category === 'semua' ? 'Semua' : category === 'portfolio' ? 'Portfolio' : 'Landing Page'}
                  </button>
                ))}
              </div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white/5 backdrop-blur-lg rounded-2xl overflow-hidden border border-white/10 hover:border-purple-400/50 transition-all duration-300 group"
                >
                  <div className="relative overflow-hidden">
                    <img  
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      alt={product.title}
                     src="https://images.unsplash.com/photo-1635865165118-917ed9e20936" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute bottom-4 left-4 right-4 flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 bg-white/20 border-white/30 text-white hover:bg-white/30"
                          onClick={() => handleDemo(product)}
                        >
                          <Eye size={16} className="mr-1" /> Demo
                        </Button>
                        <Button
                          size="sm"
                          className="bg-purple-600 hover:bg-purple-700 text-white"
                          onClick={() => setSelectedProduct(product)}
                        >
                          <ShoppingCart size={16} />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs bg-purple-600/20 text-purple-300 px-2 py-1 rounded-full">
                        {product.category === 'portfolio' ? 'Portfolio' : 'Landing Page'}
                      </span>
                      <div className="flex items-center text-yellow-400">
                        <Star size={14} fill="currentColor" />
                        <span className="text-xs text-gray-300 ml-1">{product.rating}</span>
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold text-white mb-2">{product.title}</h3>
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">{product.description}</p>

                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <span className="text-xl font-bold text-white">{product.price}</span>
                        <span className="text-sm text-gray-400 line-through ml-2">{product.originalPrice}</span>
                      </div>
                      <span className="text-xs text-gray-400">{product.reviews} ulasan</span>
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                      onClick={() => handlePurchase(product)}
                    >
                      Beli Sekarang
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-lg rounded-3xl p-8 md:p-12 text-center border border-white/10"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Siap Mengembangkan Bisnis Digital Anda?
              </h2>
              <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                Dapatkan konsultasi gratis dan temukan solusi digital terbaik untuk bisnis Anda bersama KOCAY Studio
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-xl"
                  onClick={handleContact}
                >
                  Konsultasi Gratis
                </Button>
                <Button 
                  variant="outline"
                  size="lg"
                  className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white px-8 py-3 rounded-xl"
                  onClick={() => document.getElementById('products').scrollIntoView({ behavior: 'smooth' })}
                >
                  Lihat Semua Produk
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer id="contact" className="py-12 px-4 border-t border-white/10">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="md:col-span-2">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold text-lg">K</span>
                  </div>
                  <div>
                    <span className="text-xl font-bold text-white">KOCAY Studio</span>
                    <p className="text-sm text-purple-300">Digital Products</p>
                  </div>
                </div>
                <p className="text-gray-400 mb-4 max-w-md">
                  Spesialis dalam pembuatan portfolio dan landing page premium dengan desain responsif dan performa tinggi untuk bisnis digital Anda.
                </p>
                <div className="flex space-x-4">
                  <Button variant="outline" size="sm" className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white">
                    <Heart size={16} />
                  </Button>
                  <Button variant="outline" size="sm" className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white">
                    <Share2 size={16} />
                  </Button>
                </div>
              </div>

              <div>
                <span className="text-white font-semibold mb-4 block">Produk</span>
                <ul className="space-y-2 text-gray-400">
                  <li><a href="#" className="hover:text-purple-300 transition-colors">Portfolio Bisnis</a></li>
                  <li><a href="#" className="hover:text-purple-300 transition-colors">Landing Page</a></li>
                  <li><a href="#" className="hover:text-purple-300 transition-colors">Template Premium</a></li>
                  <li><a href="#" className="hover:text-purple-300 transition-colors">Custom Design</a></li>
                </ul>
              </div>

              <div>
                <span className="text-white font-semibold mb-4 block">Kontak</span>
                <ul className="space-y-2 text-gray-400">
                  <li>Email: hello@kocaystudio.com</li>
                  <li>WhatsApp: +62 812-3456-7890</li>
                  <li>Instagram: @kocaystudio</li>
                  <li>Telegram: @kocaystudio</li>
                </ul>
              </div>
            </div>

            <div className="border-t border-white/10 mt-8 pt-8 text-center">
              <p className="text-gray-400">
                © 2024 KOCAY Studio. Semua hak cipta dilindungi.
              </p>
            </div>
          </div>
        </footer>

        {/* Product Detail Modal */}
        <AnimatePresence>
          {selectedProduct && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
              onClick={() => setSelectedProduct(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-slate-900 rounded-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-white/10"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">{selectedProduct.title}</h3>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center text-yellow-400">
                        <Star size={16} fill="currentColor" />
                        <span className="text-white ml-1">{selectedProduct.rating}</span>
                        <span className="text-gray-400 ml-1">({selectedProduct.reviews} ulasan)</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedProduct(null)}
                    className="text-gray-400 hover:text-white p-2"
                  >
                    <X size={24} />
                  </button>
                </div>

                <img  
                  className="w-full h-64 object-cover rounded-xl mb-6"
                  alt={selectedProduct.title}
                 src="https://images.unsplash.com/photo-1635865165118-917ed9e20936" />

                <p className="text-gray-300 mb-6">{selectedProduct.description}</p>

                <div className="mb-6">
                  <h4 className="text-white font-semibold mb-3">Fitur Unggulan:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {selectedProduct.features.map((feature, index) => (
                      <div key={index} className="flex items-center text-gray-300">
                        <CheckCircle size={16} className="text-green-400 mr-2" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between mb-6">
                  <div>
                    <span className="text-2xl font-bold text-white">{selectedProduct.price}</span>
                    <span className="text-gray-400 line-through ml-2">{selectedProduct.originalPrice}</span>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                    onClick={() => handlePurchase(selectedProduct)}
                  >
                    <ShoppingCart size={16} className="mr-2" />
                    Beli Sekarang
                  </Button>
                  <Button
                    variant="outline"
                    className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white"
                    onClick={() => handleDemo(selectedProduct)}
                  >
                    <Play size={16} className="mr-2" />
                    Demo
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}

export default App;
